# MF1750 基础六色显示驱动 D0

版本：`MF1750_BASIC_DRIVER_D0_20260906`

这是给同事进行基础展示和接口联调的最小 PlatformIO 工程。它包含当前 MF1750 Rev A1 双 SPD1657B 级联的基础驱动、六色帧上传、内置色条测试和 Web UI；不包含 EC5 未知码、seed/perturbation、runtime-LUT、HOLD、P2-C 或其他实验固件。

## 硬件

- ESP32-S3 DevKitC-1，需有 8 MB OPI PSRAM 配置
- MF1750 Rev A1，1024×600，双 SPD1657B；两侧各 512×600
- 所有 EPD 逻辑信号使用 3.3 V
- 当前基线引脚：BUSY=GPIO4、RST=GPIO5、DC=GPIO6、CS1=GPIO7、CS2=GPIO10、MOSI=GPIO11、SCK=GPIO12
- CS1/CS2 的 R15/R16 硬件配置必须与 Rev A1 基线一致；不要在未核对硬件的情况下接线

## 构建和刷写

1. 安装 VS Code + PlatformIO，或安装 PlatformIO Core。
2. 复制 Wi-Fi 模板并填写测试网络：

   ```powershell
   Copy-Item src\wifi_secrets.example.h src\wifi_secrets.h
   ```

   `src/wifi_secrets.h` 只保存在本机，不要发回压缩包或提交 Git。

3. 编译：

   ```powershell
   pio run -e esp32-s3-devkitc-1
   ```

4. 将开发板接入后再指定实际串口刷写；本包没有硬编码 COM：

   ```powershell
   pio run -e esp32-s3-devkitc-1 -t upload --upload-port COMx
   pio device monitor --port COMx --baud 115200
   ```

5. 启动日志会打印 STA IP；STA 失败时才回退到 AP。浏览器打开设备 IP 的根路径即可使用 Web UI。

## 基础展示

Web UI 提供：

- 上传 1024×600 图片并转换为六色帧；
- Atkinson、Floyd–Steinberg、无抖动和 8×8 Bayer 预览；
- 内置 MAP_ORIENT_V1 基础驱动验收；
- 黑、白、色条等基础测试图。

有效基础像素码为：黑 `0x0`、白 `0x1`、黄 `0x2`、红 `0x3`、蓝 `0x5`、绿 `0x6`。4bpp 容器不表示支持 16 个独立颜色。

## 使用边界

这是未认证的调试网络固件，HTTP 接口没有应用层认证，只应放在隔离网络。一次全屏刷新可能持续约 30–35 秒；刷新期间不要复位、重发请求或断开电源。不要调用未知码、未知寄存器、VCOM sweep、BUSY 中断或实验性接口。真实硬件测试必须遵循项目现场交接文档和单次授权。

## 可复现信息

源文件来自 ESP32_C73 工作区当前基础 `esp32-s3-devkitc-1` 环境。压缩包旁附 `SHA256SUMS.txt`；同事回传问题时请同时提供固件构建输出、串口启动日志、设备 IP、板卡 revision 和压缩包版本。
